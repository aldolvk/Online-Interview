package com.example.onlineinterview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.onlineinterview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding :ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ivChat.setOnClickListener{
            startActivity(Intent(this@MainActivity, ChatActivity :: class.java))
        }


        binding.btnInterview.setOnClickListener{
            startActivity(Intent(this@MainActivity, InterviewActivity :: class.java))
        }

        binding.ivRecord.setOnClickListener{
            startActivity(Intent(this@MainActivity, InterActivity :: class.java))
        }

        binding.ivHistory.setOnClickListener{
            startActivity((Intent(this@MainActivity, HistoryActivity:: class.java)))
        }

        binding.ivHint.setOnClickListener{
            startActivity(Intent(this@MainActivity, HintActivity :: class.java))
        }

    }

}